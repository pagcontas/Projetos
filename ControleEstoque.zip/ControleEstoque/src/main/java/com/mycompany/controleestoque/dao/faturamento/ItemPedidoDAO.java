package com.mycompany.controleestoque.dao.faturamento;

import com.xpert.persistence.dao.BaseDAO;
import com.mycompany.controleestoque.modelo.faturamento.ItemPedido;
import javax.ejb.Local;

/**
 *
 * @author juniel
 */
@Local
public interface ItemPedidoDAO extends BaseDAO<ItemPedido> {
    
}
