package com.mycompany.controleestoque.dao.email;

import com.xpert.persistence.dao.BaseDAO;
import com.mycompany.controleestoque.modelo.email.ModeloEmail;
import javax.ejb.Local;

/**
 *
 * @author ayslan
 */
@Local
public interface ModeloEmailDAO extends BaseDAO<ModeloEmail> {
    
}
