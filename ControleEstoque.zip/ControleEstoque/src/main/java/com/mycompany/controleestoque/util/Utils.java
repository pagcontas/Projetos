package com.mycompany.controleestoque.util;

public class Utils {

}
