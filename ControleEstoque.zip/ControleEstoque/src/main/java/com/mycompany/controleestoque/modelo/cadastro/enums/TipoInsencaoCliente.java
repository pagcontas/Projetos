/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.controleestoque.modelo.cadastro.enums;

/**
 *
 * @author killerbee
 */
public enum TipoInsencaoCliente {

    
    CONTRIBUIENTE(1, "Contribuiente ICMS"),
    ISENTO(2, "Isento"),
    NAOCONTRIBUIENTE(9, "Não Contribuiente");

    private TipoInsencaoCliente(int num, String descricao) {
        this.descricao = descricao;
        this.num = num;
    }
    private String descricao;
    private int num;

    public int getNum() {
        return num;
    }

    public String getDescricao() {
        return descricao;
    }
}
