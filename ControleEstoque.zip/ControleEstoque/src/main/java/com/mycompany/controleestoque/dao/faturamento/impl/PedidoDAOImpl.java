package com.mycompany.controleestoque.dao.faturamento.impl;

import com.mycompany.controleestoque.application.BaseDAOImpl;
import com.mycompany.controleestoque.dao.faturamento.PedidoDAO;
import com.mycompany.controleestoque.modelo.faturamento.Pedido;
import javax.ejb.Stateless;

/**
 *
 * @author juniel
 */
@Stateless
public class PedidoDAOImpl extends BaseDAOImpl<Pedido> implements PedidoDAO {
}
