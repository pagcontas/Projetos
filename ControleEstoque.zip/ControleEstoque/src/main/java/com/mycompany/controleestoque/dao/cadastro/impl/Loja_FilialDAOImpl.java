package com.mycompany.controleestoque.dao.cadastro.impl;

import com.mycompany.controleestoque.application.BaseDAOImpl;
import com.mycompany.controleestoque.dao.cadastro.Loja_FilialDAO;
import com.mycompany.controleestoque.modelo.cadastro.Loja_Filial;
import javax.ejb.Stateless;

/**
 *
 * @author juniel
 */
@Stateless
public class Loja_FilialDAOImpl extends BaseDAOImpl<Loja_Filial> implements Loja_FilialDAO {
}
