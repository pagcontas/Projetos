package com.mycompany.controleestoque.dao.configuracao;

import com.mycompany.controleestoque.modelo.configuracao.ErroSistema;
import com.xpert.persistence.dao.BaseDAO;
import javax.ejb.Local;

/**
 *
 * @author
 */
@Local
public interface ErroSistemaDAO extends BaseDAO<ErroSistema> {
    
}
