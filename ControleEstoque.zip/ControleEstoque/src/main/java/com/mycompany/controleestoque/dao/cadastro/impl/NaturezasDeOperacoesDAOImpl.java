package com.mycompany.controleestoque.dao.cadastro.impl;

import com.mycompany.controleestoque.application.BaseDAOImpl;
import com.mycompany.controleestoque.dao.cadastro.NaturezasDeOperacoesDAO;
import com.mycompany.controleestoque.modelo.cadastro.NaturezasDeOperacoes;
import javax.ejb.Stateless;

/**
 *
 * @author juniel
 */
@Stateless
public class NaturezasDeOperacoesDAOImpl extends BaseDAOImpl<NaturezasDeOperacoes> implements NaturezasDeOperacoesDAO {
}
