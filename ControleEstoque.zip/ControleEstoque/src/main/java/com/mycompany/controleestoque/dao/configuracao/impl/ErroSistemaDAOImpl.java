package com.mycompany.controleestoque.dao.configuracao.impl;

import com.mycompany.controleestoque.application.BaseDAOImpl;
import com.mycompany.controleestoque.dao.configuracao.ErroSistemaDAO;
import com.mycompany.controleestoque.modelo.configuracao.ErroSistema;
import javax.ejb.Stateless;

/**
 *
 * @author
 */
@Stateless
public class ErroSistemaDAOImpl extends BaseDAOImpl<ErroSistema> implements ErroSistemaDAO {
}
