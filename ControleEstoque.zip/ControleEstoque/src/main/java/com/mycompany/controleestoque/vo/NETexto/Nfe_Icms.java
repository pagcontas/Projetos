/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.controleestoque.vo.NETexto;


import java.io.Serializable;

public class Nfe_Icms implements Serializable
{
  private String n11Orig;
  private String n12Cst;
  private String n12ACSosn;
  private String n13Modbc;
  private String n14Predbc;
  private String n15Vbc;
  private String n16Picms;
  private String n17Vicms;
  private String n18Modbcst;
  private String n19Pmvast;
  private String n20Predbcst;
  private String n21Vbcst;
  private String n22Picmsst;
  private String n23Vicmsst;
  private String n24Ufst;
  private String n25Pbcop;
  private String n26Vbcstret;
  private String n27Vicmsstret;
  private String n28Motdesicms;
  private String n29Pcredsn;
  private String n30Vcredicmssn;
  private String n31Vbcstdest;
  private String n32Vicmsstdest;

  public Nfe_Icms()
  {
    inicializa();
  }

  public Nfe_Icms(String n11Orig, String n12Cst, String n12ACSosn, String n13Modbc, String n14Predbc, String n15Vbc, String n16Picms, String n17Vicms, String n18Modbcst, String n19Pmvast, String n20Predbcst, String n21Vbcst, String n22Picmsst, String n23Vicmsst, String n24Ufst, String n25Pbcop, String n26Vbcstret, String n27Vicmsstret, String n28Motdesicms, String n29Pcredsn, String n30Vcredicmssn, String n31Vbcstdest, String n32Vicmsstdest) {
    this.n11Orig = n11Orig;
    this.n12Cst = n12Cst;
    this.n12ACSosn = n12ACSosn;
    this.n13Modbc = n13Modbc;
    this.n14Predbc = n14Predbc;
    this.n15Vbc = n15Vbc;
    this.n16Picms = n16Picms;
    this.n17Vicms = n17Vicms;
    this.n18Modbcst = n18Modbcst;
    this.n19Pmvast = n19Pmvast;
    this.n20Predbcst = n20Predbcst;
    this.n21Vbcst = n21Vbcst;
    this.n22Picmsst = n22Picmsst;
    this.n23Vicmsst = n23Vicmsst;
    this.n24Ufst = n24Ufst;
    this.n25Pbcop = n25Pbcop;
    this.n26Vbcstret = n26Vbcstret;
    this.n27Vicmsstret = n27Vicmsstret;
    this.n28Motdesicms = n28Motdesicms;
    this.n29Pcredsn = n29Pcredsn;
    this.n30Vcredicmssn = n30Vcredicmssn;
    this.n31Vbcstdest = n31Vbcstdest;
    this.n32Vicmsstdest = n32Vicmsstdest;
  }

  private void inicializa() {
    this.n11Orig = "";
    this.n12Cst = "";
    this.n12ACSosn = "";
    this.n13Modbc = "";
    this.n14Predbc = "";
    this.n15Vbc = "";
    this.n16Picms = "";
    this.n17Vicms = "";
    this.n18Modbcst = "";
    this.n19Pmvast = "";
    this.n20Predbcst = "";
    this.n21Vbcst = "";
    this.n22Picmsst = "";
    this.n23Vicmsst = "";
    this.n24Ufst = "";
    this.n25Pbcop = "";
    this.n26Vbcstret = "";
    this.n27Vicmsstret = "";
    this.n28Motdesicms = "";
    this.n29Pcredsn = "";
    this.n30Vcredicmssn = "";
    this.n31Vbcstdest = "";
    this.n32Vicmsstdest = "";
  }

  public String getN11Orig() {
    return this.n11Orig;
  }

  public void setN11Orig(String n11Orig) {
    this.n11Orig = n11Orig;
  }
  public String getN12Cst() {
    return this.n12Cst;
  }

  public void setN12Cst(String n12Cst) {
    this.n12Cst = n12Cst;
  }
  public String getN12ACSosn() {
    return this.n12ACSosn;
  }

  public void setN12ACSosn(String n12ACSosn) {
    this.n12ACSosn = n12ACSosn;
  }
  public String getN13Modbc() {
    return this.n13Modbc;
  }

  public void setN13Modbc(String n13Modbc) {
    this.n13Modbc = n13Modbc;
  }
  public String getN14Predbc() {
    return this.n14Predbc;
  }

  public void setN14Predbc(String n14Predbc) {
    this.n14Predbc = n14Predbc;
  }
  public String getN15Vbc() {
    return this.n15Vbc;
  }

  public void setN15Vbc(String n15Vbc) {
    this.n15Vbc = n15Vbc;
  }
  public String getN16Picms() {
    return this.n16Picms;
  }

  public void setN16Picms(String n16Picms) {
    this.n16Picms = n16Picms;
  }
  public String getN17Vicms() {
    return this.n17Vicms;
  }

  public void setN17Vicms(String n17Vicms) {
    this.n17Vicms = n17Vicms;
  }
  public String getN18Modbcst() {
    return this.n18Modbcst;
  }

  public void setN18Modbcst(String n18Modbcst) {
    this.n18Modbcst = n18Modbcst;
  }
  public String getN19Pmvast() {
    return this.n19Pmvast;
  }

  public void setN19Pmvast(String n19Pmvast) {
    this.n19Pmvast = n19Pmvast;
  }
  public String getN20Predbcst() {
    return this.n20Predbcst;
  }

  public void setN20Predbcst(String n20Predbcst) {
    this.n20Predbcst = n20Predbcst;
  }
  public String getN21Vbcst() {
    return this.n21Vbcst;
  }

  public void setN21Vbcst(String n21Vbcst) {
    this.n21Vbcst = n21Vbcst;
  }
  public String getN22Picmsst() {
    return this.n22Picmsst;
  }

  public void setN22Picmsst(String n22Picmsst) {
    this.n22Picmsst = n22Picmsst;
  }
  public String getN23Vicmsst() {
    return this.n23Vicmsst;
  }

  public void setN23Vicmsst(String n23Vicmsst) {
    this.n23Vicmsst = n23Vicmsst;
  }
  public String getN24Ufst() {
    return this.n24Ufst;
  }

  public void setN24Ufst(String n24Ufst) {
    this.n24Ufst = n24Ufst;
  }
  public String getN25Pbcop() {
    return this.n25Pbcop;
  }

  public void setN25Pbcop(String n25Pbcop) {
    this.n25Pbcop = n25Pbcop;
  }
  public String getN26Vbcstret() {
    return this.n26Vbcstret;
  }

  public void setN26Vbcstret(String n26Vbcstret) {
    this.n26Vbcstret = n26Vbcstret;
  }
  public String getN27Vicmsstret() {
    return this.n27Vicmsstret;
  }

  public void setN27Vicmsstret(String n27Vicmsstret) {
    this.n27Vicmsstret = n27Vicmsstret;
  }
  public String getN28Motdesicms() {
    return this.n28Motdesicms;
  }

  public void setN28Motdesicms(String n28Motdesicms) {
    this.n28Motdesicms = n28Motdesicms;
  }
  public String getN29Pcredsn() {
    return this.n29Pcredsn;
  }

  public void setN29Pcredsn(String n29Pcredsn) {
    this.n29Pcredsn = n29Pcredsn;
  }
  public String getN30Vcredicmssn() {
    return this.n30Vcredicmssn;
  }

  public void setN30Vcredicmssn(String n30Vcredicmssn) {
    this.n30Vcredicmssn = n30Vcredicmssn;
  }
  public String getN31Vbcstdest() {
    return this.n31Vbcstdest;
  }

  public void setN31Vbcstdest(String n31Vbcstdest) {
    this.n31Vbcstdest = n31Vbcstdest;
  }
  public String getN32Vicmsstdest() {
    return this.n32Vicmsstdest;
  }

  public void setN32Vicmsstdest(String n32Vicmsstdest) {
    this.n32Vicmsstdest = n32Vicmsstdest;
  }
}
