package com.mycompany.controleestoque.dao.faturamento;

import com.xpert.persistence.dao.BaseDAO;
import com.mycompany.controleestoque.modelo.faturamento.Venda;
import javax.ejb.Local;

/**
 *
 * @author juniel
 */
@Local
public interface VendaDAO extends BaseDAO<Venda> {
    
}
