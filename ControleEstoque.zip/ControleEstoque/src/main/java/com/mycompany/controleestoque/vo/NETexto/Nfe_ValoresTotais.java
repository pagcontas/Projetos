/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.controleestoque.vo.NETexto;

import java.io.Serializable;

public class Nfe_ValoresTotais implements Serializable {

    private String w03Vbc;
    private String w04Vicms;
    private String w05Vbcst;
    private String w06Vst;
    private String w07Vprod;
    private String w08Vfrete;
    private String w09Vseg;
    private String w10Vdesc;
    private String w11Vii;
    private String w12Vipi;
    private String w13Pis;
    private String w14Vconfins;
    private String w15Voutro;
    private String w16Vnf;
    private String w18Vserv;
    private String w19Vbc;
    private String w20Viss;
    private String w21Vpis;
    private String w22Vconfins;
    private String w24Vretpis;
    private String w25Vretconfins;
    private String w26Vretcsll;
    private String w27Vbcirrf;
    private String w28Virrf;
    private String w29Vbcretprev;
    private String w30Vretprev;

    public Nfe_ValoresTotais() {
        inicializa();
    }

    public Nfe_ValoresTotais(String w03Vbc, String w04Vicms, String w05Vbcst, String w06Vst, String w07Vprod, String w08Vfrete, String w09Vseg, String w10Vdesc, String w11Vii, String w12Vipi, String w13Pis, String w14Vconfins, String w15Voutro, String w16Vnf, String w18Vserv, String w19Vbc, String w20Viss, String w21Vpis, String w22Vconfins, String w24Vretpis, String w25Vretconfins, String w26Vretcsll, String w27Vbcirrf, String w28Virrf, String w29Vbcretprev, String w30Vretprev) {
        this.w03Vbc = w03Vbc;
        this.w04Vicms = w04Vicms;
        this.w05Vbcst = w05Vbcst;
        this.w06Vst = w06Vst;
        this.w07Vprod = w07Vprod;
        this.w08Vfrete = w08Vfrete;
        this.w09Vseg = w09Vseg;
        this.w10Vdesc = w10Vdesc;
        this.w11Vii = w11Vii;
        this.w12Vipi = w12Vipi;
        this.w13Pis = w13Pis;
        this.w14Vconfins = w14Vconfins;
        this.w15Voutro = w15Voutro;
        this.w16Vnf = w16Vnf;
        this.w18Vserv = w18Vserv;
        this.w19Vbc = w19Vbc;
        this.w20Viss = w20Viss;
        this.w21Vpis = w21Vpis;
        this.w22Vconfins = w22Vconfins;
        this.w24Vretpis = w24Vretpis;
        this.w25Vretconfins = w25Vretconfins;
        this.w26Vretcsll = w26Vretcsll;
        this.w27Vbcirrf = w27Vbcirrf;
        this.w28Virrf = w28Virrf;
        this.w29Vbcretprev = w29Vbcretprev;
        this.w30Vretprev = w30Vretprev;
    }

    private void inicializa() {
        this.w03Vbc = "";
        this.w04Vicms = "";
        this.w05Vbcst = "";
        this.w06Vst = "";
        this.w07Vprod = "";
        this.w08Vfrete = "";
        this.w09Vseg = "";
        this.w10Vdesc = "";
        this.w11Vii = "";
        this.w12Vipi = "";
        this.w13Pis = "";
        this.w14Vconfins = "";
        this.w15Voutro = "";
        this.w16Vnf = "";
        this.w18Vserv = "";
        this.w19Vbc = "";
        this.w20Viss = "";
        this.w21Vpis = "";
        this.w22Vconfins = "";
        this.w24Vretpis = "";
        this.w25Vretconfins = "";
        this.w26Vretcsll = "";
        this.w27Vbcirrf = "";
        this.w28Virrf = "";
        this.w29Vbcretprev = "";
        this.w30Vretprev = "";
    }

    public String getW03Vbc() {
        return this.w03Vbc;
    }

    public void setW03Vbc(String w03Vbc) {
        this.w03Vbc = w03Vbc;
    }

    public String getW04Vicms() {
        return this.w04Vicms;
    }

    public void setW04Vicms(String w04Vicms) {
        this.w04Vicms = w04Vicms;
    }

    public String getW05Vbcst() {
        return this.w05Vbcst;
    }

    public void setW05Vbcst(String w05Vbcst) {
        this.w05Vbcst = w05Vbcst;
    }

    public String getW06Vst() {
        return this.w06Vst;
    }

    public void setW06Vst(String w06Vst) {
        this.w06Vst = w06Vst;
    }

    public String getW07Vprod() {
        return this.w07Vprod;
    }

    public void setW07Vprod(String w07Vprod) {
        this.w07Vprod = w07Vprod;
    }

    public String getW08Vfrete() {
        return this.w08Vfrete;
    }

    public void setW08Vfrete(String w08Vfrete) {
        this.w08Vfrete = w08Vfrete;
    }

    public String getW09Vseg() {
        return this.w09Vseg;
    }

    public void setW09Vseg(String w09Vseg) {
        this.w09Vseg = w09Vseg;
    }

    public String getW10Vdesc() {
        return this.w10Vdesc;
    }

    public void setW10Vdesc(String w10Vdesc) {
        this.w10Vdesc = w10Vdesc;
    }

    public String getW11Vii() {
        return this.w11Vii;
    }

    public void setW11Vii(String w11Vii) {
        this.w11Vii = w11Vii;
    }

    public String getW12Vipi() {
        return this.w12Vipi;
    }

    public void setW12Vipi(String w12Vipi) {
        this.w12Vipi = w12Vipi;
    }

    public String getW13Pis() {
        return this.w13Pis;
    }

    public void setW13Pis(String w13Pis) {
        this.w13Pis = w13Pis;
    }

    public String getW14Vconfins() {
        return this.w14Vconfins;
    }

    public void setW14Vconfins(String w14Vconfins) {
        this.w14Vconfins = w14Vconfins;
    }

    public String getW15Voutro() {
        return this.w15Voutro;
    }

    public void setW15Voutro(String w15Voutro) {
        this.w15Voutro = w15Voutro;
    }

    public String getW16Vnf() {
        return this.w16Vnf;
    }

    public void setW16Vnf(String w16Vnf) {
        this.w16Vnf = w16Vnf;
    }

    public String getW18Vserv() {
        return this.w18Vserv;
    }

    public void setW18Vserv(String w18Vserv) {
        this.w18Vserv = w18Vserv;
    }

    public String getW19Vbc() {
        return this.w19Vbc;
    }

    public void setW19Vbc(String w19Vbc) {
        this.w19Vbc = w19Vbc;
    }

    public String getW20Viss() {
        return this.w20Viss;
    }

    public void setW20Viss(String w20Viss) {
        this.w20Viss = w20Viss;
    }

    public String getW21Vpis() {
        return this.w21Vpis;
    }

    public void setW21Vpis(String w21Vpis) {
        this.w21Vpis = w21Vpis;
    }

    public String getW22Vconfins() {
        return this.w22Vconfins;
    }

    public void setW22Vconfins(String w22Vconfins) {
        this.w22Vconfins = w22Vconfins;
    }

    public String getW24Vretpis() {
        return this.w24Vretpis;
    }

    public void setW24Vretpis(String w24Vretpis) {
        this.w24Vretpis = w24Vretpis;
    }

    public String getW25Vretconfins() {
        return this.w25Vretconfins;
    }

    public void setW25Vretconfins(String w25Vretconfins) {
        this.w25Vretconfins = w25Vretconfins;
    }

    public String getW26Vretcsll() {
        return this.w26Vretcsll;
    }

    public void setW26Vretcsll(String w26Vretcsll) {
        this.w26Vretcsll = w26Vretcsll;
    }

    public String getW27Vbcirrf() {
        return this.w27Vbcirrf;
    }

    public void setW27Vbcirrf(String v27Vbcirrf) {
        this.w27Vbcirrf = v27Vbcirrf;
    }

    public String getW28Virrf() {
        return this.w28Virrf;
    }

    public void setW28Virrf(String w28Virrf) {
        this.w28Virrf = w28Virrf;
    }

    public String getW29Vbcretprev() {
        return this.w29Vbcretprev;
    }

    public void setW29Vbcretprev(String w29Vbcretprev) {
        this.w29Vbcretprev = w29Vbcretprev;
    }

    public String getW30Vretprev() {
        return this.w30Vretprev;
    }

    public void setW30Vretprev(String w30Vretprev) {
        this.w30Vretprev = w30Vretprev;
    }
}
