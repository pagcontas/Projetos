/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.controleestoque.constante;

/**
 *
 * @author Ayslan
 */
public class ConstantesURL {

    public static final String URL_APLICACAO = "http://localhost:8080/ControleEstoque";
}
