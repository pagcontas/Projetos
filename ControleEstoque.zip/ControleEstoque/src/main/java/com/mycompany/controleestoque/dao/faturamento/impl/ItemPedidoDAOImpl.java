package com.mycompany.controleestoque.dao.faturamento.impl;

import com.mycompany.controleestoque.application.BaseDAOImpl;
import com.mycompany.controleestoque.dao.faturamento.ItemPedidoDAO;
import com.mycompany.controleestoque.modelo.faturamento.ItemPedido;
import javax.ejb.Stateless;

/**
 *
 * @author juniel
 */
@Stateless
public class ItemPedidoDAOImpl extends BaseDAOImpl<ItemPedido> implements ItemPedidoDAO {
}
