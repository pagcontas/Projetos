package com.mycompany.controleestoque.dao.faturamento.impl;

import com.mycompany.controleestoque.application.BaseDAOImpl;
import com.mycompany.controleestoque.dao.faturamento.ItemVendaDAO;
import com.mycompany.controleestoque.modelo.faturamento.ItemVenda;
import javax.ejb.Stateless;

/**
 *
 * @author juniel
 */
@Stateless
public class ItemVendaDAOImpl extends BaseDAOImpl<ItemVenda> implements ItemVendaDAO {
}
