package com.mycompany.controleestoque.dao.email;

import com.xpert.persistence.dao.BaseDAO;
import com.mycompany.controleestoque.modelo.email.ConfiguracaoEmail;
import javax.ejb.Local;

/**
 *
 * @author ayslan
 */
@Local
public interface ConfiguracaoEmailDAO extends BaseDAO<ConfiguracaoEmail> {
    
}
