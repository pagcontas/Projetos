package com.mycompany.controleestoque.dao.cadastro;

import com.xpert.persistence.dao.BaseDAO;
import com.mycompany.controleestoque.modelo.cadastro.Banco;
import javax.ejb.Local;

/**
 *
 * @author juniel
 */
@Local
public interface BancoDAO extends BaseDAO<Banco> {
    
}
