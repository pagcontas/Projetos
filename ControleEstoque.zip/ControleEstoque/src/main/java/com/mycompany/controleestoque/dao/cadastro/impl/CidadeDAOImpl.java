package com.mycompany.controleestoque.dao.cadastro.impl;

import com.mycompany.controleestoque.application.BaseDAOImpl;
import com.mycompany.controleestoque.dao.cadastro.CidadeDAO;
import com.mycompany.controleestoque.modelo.cadastro.Cidade;
import javax.ejb.Stateless;

/**
 *
 * @author juniel
 */
@Stateless
public class CidadeDAOImpl extends BaseDAOImpl<Cidade> implements CidadeDAO {
}
